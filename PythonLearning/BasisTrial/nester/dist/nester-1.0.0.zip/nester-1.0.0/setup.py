#!/usr/bin/env python
# -*- coding: utf-8 -*-

from distutils.core import setup

setup(
        name         = 'nester',
        version      = '1.0.0',
        py_modules   = ['nester'],
        author       = 'joyce\'s husband',
        author_email = 'jminhe@qq.com',
        url          = '',
        description  = 'A sample printer of nested lists'
)